plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.leaves.tracker"
    compileSdk = 34
    defaultConfig { applicationId = "com.leaves.tracker"; minSdk = 26; targetSdk = 34; versionCode = 3; versionName = "3.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    signingConfigs { getByName("debug") { storeFile = file("debug.keystore"); storePassword = "android"; keyAlias = "androiddebugkey"; keyPassword = "android" } }
    kotlinOptions { jvmTarget = "17" }
}
