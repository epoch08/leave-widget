package com.leaves.tracker

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.View
import android.widget.RemoteViews
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

object Store {
    const val MAX = 9
    val names = linkedMapOf("BL" to "Business Laws", "PP" to "Public Policy", "TLD" to "Talent and Leadership Dev.", "BEM" to "Behavioral Economics", "FTSA" to "Financial Time Series", "FPM" to "Project Management", "IGT" to "Game Theory", "ODM" to "Optimization for Decisions")
    val colors = mapOf("BL" to 0xFFFBD9AE.toInt(), "PP" to 0xFFCFE0FB.toInt(), "TLD" to 0xFFDCCDF5.toInt(), "BEM" to 0xFFCDEED8.toInt(), "FTSA" to 0xFFFDF0B5.toInt(), "FPM" to 0xFFF9CFDC.toInt(), "IGT" to 0xFFC4EEF2.toInt(), "ODM" to 0xFFE6D8C6.toInt())
    val tt: Map<Int, List<Pair<String, String>>> = mapOf(
        1 to listOf("10:30 am" to "FPM", "1:45 pm" to "BL", "4:15 pm" to "BEM", "5:30 pm" to "IGT"),
        2 to listOf("8:00 am" to "PP", "9:15 am" to "TLD", "11:45 am" to "FPM", "3:00 pm" to "FTSA", "4:15 pm" to "ODM", "5:30 pm" to "BL"),
        3 to listOf("8:00 am" to "BEM", "10:30 am" to "FTSA", "1:45 pm" to "PP", "3:00 pm" to "TLD", "4:15 pm" to "IGT", "5:30 pm" to "ODM"),
        4 to listOf("9:15 am" to "IGT", "10:30 am" to "BL", "11:45 am" to "FPM", "3:00 pm" to "ODM"),
        5 to listOf("8:00 am" to "FTSA", "1:45 pm" to "BEM", "3:00 pm" to "PP", "4:15 pm" to "TLD"))
    fun prefs(c: Context) = c.getSharedPreferences("leaves", Context.MODE_PRIVATE)
    fun classes(d: LocalDate): List<Pair<String, String>> {
        val s = d.toString()
        if (s < "2026-11-02" || s > "2027-03-07" || (s >= "2026-12-28" && s <= "2027-01-04")) return emptyList()
        return tt[d.dayOfWeek.value] ?: emptyList()
    }
    fun used(c: Context, code: String) = prefs(c).all.count { it.value == "A" && it.key.endsWith("|$code") }
    fun total(c: Context) = prefs(c).all.count { it.value == "A" }
}

class LeaveWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { draw(context, mgr, it) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION) {
            val key = intent.getStringExtra("key") ?: return
            val p = Store.prefs(context)
            val next = when (p.getString(key, "P")) { "P" -> "A"; "A" -> "C"; else -> "P" }
            val e = p.edit()
            if (next == "P") e.remove(key) else e.putString(key, next)
            e.apply()
            refresh(context)
        } else super.onReceive(context, intent)
    }

    companion object {
        const val ACTION = "com.leaves.tracker.TOGGLE"

        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            m.getAppWidgetIds(ComponentName(c, LeaveWidget::class.java)).forEach { draw(c, m, it) }
        }

        fun draw(c: Context, m: AppWidgetManager, id: Int) {
            val today = LocalDate.now()
            val list = Store.classes(today)
            val p = Store.prefs(c)
            val rv = RemoteViews(c.packageName, R.layout.widget)
            rv.setTextViewText(R.id.title, today.dayOfWeek.getDisplayName(TextStyle.FULL, Locale.getDefault()))
            rv.setTextViewText(R.id.date, "${today.dayOfMonth} ${today.month.getDisplayName(TextStyle.SHORT, Locale.getDefault())}")
            rv.setTextViewText(R.id.summary, "${Store.total(c)} leaves used")
            rv.setViewVisibility(R.id.empty, if (list.isEmpty()) View.VISIBLE else View.GONE)
            for (i in 0..5) {
                fun v(n: String) = c.resources.getIdentifier(n + i, "id", c.packageName)
                if (i >= list.size) { rv.setViewVisibility(v("row"), View.GONE); continue }
                val (time, code) = list[i]
                val key = "$today|$code"
                val state = p.getString(key, "P")
                val left = Store.MAX - Store.used(c, code)
                rv.setViewVisibility(v("row"), View.VISIBLE)
                rv.setInt(v("s"), "setBackgroundColor", Store.colors[code] ?: 0xFFFFFFFF.toInt())
                rv.setTextViewText(v("c"), code)
                rv.setTextViewText(v("t"), time)
                rv.setTextViewText(v("l"), "$left left")
                rv.setTextColor(v("l"), if (left <= 0) 0xFFFF7384.toInt() else if (left <= 2) 0xFFFFB648.toInt() else 0xFF9AA2C8.toInt())
                rv.setTextViewText(v("st"), when (state) { "A" -> "✕ Absent"; "C" -> "Cancelled"; else -> "✓ Present" })
                rv.setTextColor(v("st"), when (state) { "A" -> 0xFFFF7384.toInt(); "C" -> 0xFF9AA2C8.toInt(); else -> 0xFF4CD391.toInt() })
                val intent = Intent(c, LeaveWidget::class.java).setAction(ACTION).putExtra("key", key).setData(Uri.parse("leaves://x/$today/$code"))
                rv.setOnClickPendingIntent(v("row"), PendingIntent.getBroadcast(c, i, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            }
            m.updateAppWidget(id, rv)
        }
    }
}
