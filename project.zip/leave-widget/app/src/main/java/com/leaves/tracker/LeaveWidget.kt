package com.leaves.tracker

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.net.Uri
import android.view.View
import android.widget.RemoteViews
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

object Store {
    const val MAX = 9
    const val RESERVE = 2
    val names = linkedMapOf("BL" to "Business Laws", "PP" to "Public Policy", "TLD" to "Talent and Leadership Dev.", "BEM" to "Behavioral Economics", "FTSA" to "Financial Time Series", "FPM" to "Project Management", "IGT" to "Game Theory", "ODM" to "Optimization for Decisions")
    val colors = mapOf("BL" to 0xFFFBD9AE.toInt(), "PP" to 0xFFCFE0FB.toInt(), "TLD" to 0xFFDCCDF5.toInt(), "BEM" to 0xFFCDEED8.toInt(), "FTSA" to 0xFFFDF0B5.toInt(), "FPM" to 0xFFF9CFDC.toInt(), "IGT" to 0xFFC4EEF2.toInt(), "ODM" to 0xFFE6D8C6.toInt())
    val tt: Map<Int, List<Pair<String, String>>> = mapOf(
        1 to listOf("10:30 am" to "FPM", "1:45 pm" to "BL", "4:15 pm" to "BEM", "5:30 pm" to "IGT"),
        2 to listOf("8:00 am" to "PP", "9:15 am" to "TLD", "11:45 am" to "FPM", "3:00 pm" to "FTSA", "4:15 pm" to "ODM", "5:30 pm" to "BL"),
        3 to listOf("8:00 am" to "BEM", "10:30 am" to "FTSA", "1:45 pm" to "PP", "3:00 pm" to "TLD", "4:15 pm" to "IGT", "5:30 pm" to "ODM"),
        4 to listOf("9:15 am" to "IGT", "10:30 am" to "BL", "11:45 am" to "FPM", "3:00 pm" to "ODM"),
        5 to listOf("8:00 am" to "FTSA", "1:45 pm" to "BEM", "3:00 pm" to "PP", "4:15 pm" to "TLD"))

    fun prefs(c: Context) = c.getSharedPreferences("leaves", Context.MODE_PRIVATE)

    fun isDark(c: Context): Boolean = when (prefs(c).getString("_theme", null)) {
        "dark" -> true
        "light" -> false
        else -> (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    fun blend(a: Int, b: Int, t: Float): Int {
        val r = (Color.red(a) * (1 - t) + Color.red(b) * t).toInt()
        val g = (Color.green(a) * (1 - t) + Color.green(b) * t).toInt()
        val bl = (Color.blue(a) * (1 - t) + Color.blue(b) * t).toInt()
        return Color.rgb(r, g, bl)
    }

    fun selected(c: Context): List<String>? = prefs(c).getString("_sel", null)?.split(",")?.filter { it.isNotEmpty() }

    fun todayList(c: Context, d: LocalDate): List<Triple<String, String, String>> {
        val sel = selected(c) ?: return emptyList()
        val s = d.toString()
        val r = ArrayList<Triple<String, String, String>>()
        if (!(s < "2026-11-02" || s > "2027-03-07" || (s >= "2026-12-28" && s <= "2027-01-04")))
            (tt[d.dayOfWeek.value] ?: emptyList()).filter { it.second in sel }.forEach { r.add(Triple(it.first, it.second, "$s|${it.second}")) }
        prefs(c).all.keys.filter { val p = it.split("|"); p.size == 3 && p[0] == s && p[1] in sel }.sorted().forEach { r.add(Triple("Extra", it.split("|")[1], it)) }
        return r.take(6)
    }

    fun used(c: Context, code: String) = prefs(c).all.count { it.value == "A" && it.key.split("|").let { p -> p.size >= 2 && p[1] == code } }

    fun total(c: Context) = prefs(c).all.count { it.value == "A" && it.key.contains("|") }
}

class LeaveWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { draw(context, mgr, it) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            ACTION -> {
                val key = intent.getStringExtra("key") ?: return
                val p = Store.prefs(context)
                val extra = key.split("|").size == 3
                val next = when (p.getString(key, "P")) { "P" -> "A"; "A" -> if (extra) "P" else "C"; else -> "P" }
                val e = p.edit()
                if (next == "P" && !extra) e.remove(key) else e.putString(key, next)
                e.apply()
                refresh(context)
            }
            Intent.ACTION_DATE_CHANGED, Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED -> refresh(context)
            else -> super.onReceive(context, intent)
        }
    }

    companion object {
        const val ACTION = "com.leaves.tracker.TOGGLE"

        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            m.getAppWidgetIds(ComponentName(c, LeaveWidget::class.java)).forEach { draw(c, m, it) }
        }

        fun draw(c: Context, m: AppWidgetManager, id: Int) {
            val today = LocalDate.now()
            val list = Store.todayList(c, today)
            val p = Store.prefs(c)
            val dark = Store.isDark(c)
            val ink = if (dark) 0xFFEEF0FF.toInt() else 0xFF171D3D.toInt()
            val rv = RemoteViews(c.packageName, R.layout.widget)
            val loc = Locale.getDefault()
            rv.setInt(R.id.wbg, "setColorFilter", if (dark) 0xFF171D3B.toInt() else 0xFFF3F4FA.toInt())
            rv.setTextViewText(R.id.title, "${today.dayOfWeek.getDisplayName(TextStyle.SHORT, loc)}, ${today.dayOfMonth} ${today.month.getDisplayName(TextStyle.SHORT, loc)}")
            rv.setTextColor(R.id.title, ink)
            rv.setTextViewText(R.id.summary, "${Store.total(c)} leaves used")
            rv.setTextColor(R.id.summary, if (dark) 0xFF9AA6FF.toInt() else 0xFF4452D6.toInt())
            rv.setOnClickPendingIntent(R.id.header, PendingIntent.getActivity(c, 99, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            val vis = if (list.isEmpty()) View.GONE else View.VISIBLE
            rv.setViewVisibility(R.id.rowA, vis)
            rv.setViewVisibility(R.id.rowB, vis)
            rv.setTextViewText(R.id.empty, if (Store.selected(c) == null) "Open the app and pick your subjects" else "No classes today 🎉")
            rv.setTextColor(R.id.empty, ink)
            rv.setViewVisibility(R.id.empty, if (list.isEmpty()) View.VISIBLE else View.GONE)
            val base = 0xFF1E2550.toInt()
            for (i in 0..5) {
                fun v(n: String) = c.resources.getIdentifier(n + i, "id", c.packageName)
                if (i >= list.size) { rv.setViewVisibility(v("tile"), View.INVISIBLE); continue }
                val (time, code, key) = list[i]
                val state = p.getString(key, "P")
                val left = Store.MAX - Store.used(c, code)
                val sub = Store.colors[code] ?: 0xFFFFFFFF.toInt()
                rv.setViewVisibility(v("tile"), View.VISIBLE)
                val tileColor = when (state) {
                    "A" -> if (dark) Store.blend(base, 0xFFFF6F82.toInt(), 0.40f) else 0xFFFF9AA5.toInt()
                    "C" -> if (dark) Store.blend(base, 0xFF97A0C8.toInt(), 0.22f) else 0xFFD5D9E6.toInt()
                    else -> if (dark) Store.blend(base, sub, 0.30f) else sub
                }
                rv.setInt(v("bg"), "setColorFilter", tileColor)
                rv.setTextViewText(v("c"), code)
                rv.setTextColor(v("c"), if (dark) sub else 0xFF171D3D.toInt())
                rv.setTextViewText(v("t"), time)
                rv.setTextColor(v("t"), if (dark) 0xFFAAB3DD.toInt() else 0xB3171D3D.toInt())
                rv.setTextViewText(v("l"), if (left < 0) "${-left} over" else if (left == 0) "none left" else "$left left")
                val leftColor = if (dark) when {
                    state == "A" || left <= 0 -> 0xFFFF8A99.toInt()
                    left <= Store.RESERVE -> 0xFFFFBB55.toInt()
                    else -> 0xFF52D79D.toInt()
                } else when {
                    state == "A" -> 0xFF7A0F20.toInt()
                    left <= 0 -> 0xFFB3152D.toInt()
                    left <= Store.RESERVE -> 0xFF9A5A00.toInt()
                    else -> 0xFF0B6B47.toInt()
                }
                rv.setTextColor(v("l"), leftColor)
                rv.setTextViewText(v("st"), when (state) { "A" -> "✕ Absent"; "C" -> "Cancelled"; else -> "✓ Present" })
                rv.setInt(v("st"), "setBackgroundResource", if (dark) R.drawable.pill_dark else R.drawable.pill)
                rv.setTextColor(v("st"), if (dark) when (state) { "A" -> 0xFFFF8A99.toInt(); "C" -> 0xFF97A0C8.toInt(); else -> 0xFF52D79D.toInt() } else when (state) { "A" -> 0xFFB3152D.toInt(); "C" -> 0xFF4A5378.toInt(); else -> 0xFF0B6B47.toInt() })
                val intent = Intent(c, LeaveWidget::class.java).setAction(ACTION).putExtra("key", key).setData(Uri.parse("leaves://x/$key"))
                rv.setOnClickPendingIntent(v("tile"), PendingIntent.getBroadcast(c, i, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            }
            m.updateAppWidget(id, rv)
        }
    }
}
