package com.leaves.tracker

import android.app.Activity
import android.os.Bundle
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var tv: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        tv = TextView(this)
        tv.textSize = 18f
        tv.setPadding(56, 120, 56, 56)
        val sv = ScrollView(this)
        sv.addView(tv)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        val sb = StringBuilder("Leaves used per subject\n\n")
        Store.names.forEach { (code, name) -> sb.append("$code   ${Store.used(this, code)} of ${Store.MAX}   $name\n\n") }
        sb.append("To add the widget: long-press your home screen, tap Widgets, find Leave Tracker and drag it onto the screen. Tap a class on the widget to mark it absent.")
        tv.text = sb.toString()
        LeaveWidget.refresh(this)
    }
}
