package com.leaves.tracker

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject

class Bridge(private val c: Context, private val view: View, private val onTheme: (Boolean) -> Unit) {
    @JavascriptInterface
    fun all(): String {
        val o = JSONObject()
        for ((k, v) in Store.prefs(c).all) o.put(k, v.toString())
        return o.toString()
    }

    @JavascriptInterface
    fun save(json: String) {
        val o = JSONObject(json)
        val e = Store.prefs(c).edit().clear()
        val it = o.keys()
        while (it.hasNext()) { val k = it.next(); e.putString(k, o.getString(k)) }
        e.apply()
        LeaveWidget.refresh(c)
    }

    @JavascriptInterface
    fun theme(dark: Boolean) {
        onTheme(dark)
    }

    @JavascriptInterface
    fun tick() {
        view.post { view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY) }
    }

    @JavascriptInterface
    fun copy(text: String) {
        view.post {
            val cm = c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Leave Tracker backup", text))
        }
    }
}

class MainActivity : Activity() {
    private lateinit var web: WebView

    private fun applyBars(night: Boolean) {
        val bg = if (night) 0xFF0B0F21.toInt() else 0xFFF3F4FA.toInt()
        window.setBackgroundDrawable(ColorDrawable(bg))
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = if (night) 0 else (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        if (::web.isInitialized) web.setBackgroundColor(bg)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        applyBars(Store.isDark(this))
        web.settings.javaScriptEnabled = true
        web.addJavascriptInterface(Bridge(this, web) { dark -> runOnUiThread { applyBars(dark) } }, "Android")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) web.evaluateJavascript("window.reloadData&&reloadData()", null)
        LeaveWidget.refresh(this)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.onBack?onBack():false)") { r -> if (r != "true") finish() }
    }
}
