package com.leaves.tracker

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject

class Bridge(private val c: Context) {
    @JavascriptInterface
    fun all(): String {
        val o = JSONObject()
        for ((k, v) in Store.prefs(c).all) o.put(k, v.toString())
        return o.toString()
    }

    @JavascriptInterface
    fun save(json: String) {
        val o = JSONObject(json)
        val e = Store.prefs(c).edit().clear()
        val it = o.keys()
        while (it.hasNext()) { val k = it.next(); e.putString(k, o.getString(k)) }
        e.apply()
        LeaveWidget.refresh(c)
    }
}

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val bg = if (night) 0xFF10142A.toInt() else 0xFFF2F4F8.toInt()
        window.statusBarColor = bg
        window.navigationBarColor = bg
        if (!night) window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        web = WebView(this)
        web.setBackgroundColor(bg)
        web.settings.javaScriptEnabled = true
        web.addJavascriptInterface(Bridge(this), "Android")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) web.evaluateJavascript("window.reloadData&&reloadData()", null)
        LeaveWidget.refresh(this)
    }
}
